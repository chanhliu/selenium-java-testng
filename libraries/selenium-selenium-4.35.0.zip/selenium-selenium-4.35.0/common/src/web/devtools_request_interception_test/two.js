function printScriptName() {
  document.getElementById('result').innerHTML = 'two';
}
